# IO.Swagger.Model.Address
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Street** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**State** | **string** |  | [optional] 
**Zip** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

