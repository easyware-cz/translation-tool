# SwaggerPetstoreOpenApi30.Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**street** | **String** |  | [optional] 
**city** | **String** |  | [optional] 
**state** | **String** |  | [optional] 
**zip** | **String** |  | [optional] 
