# SwaggerPetstoreOpenApi30.Customer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**username** | **String** |  | [optional] 
**address** | [**[Address]**](Address.md) |  | [optional] 
