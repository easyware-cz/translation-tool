# SwaggerPetstoreOpenApi30.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**username** | **String** |  | [optional] 
**firstName** | **String** |  | [optional] 
**lastName** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**password** | **String** |  | [optional] 
**phone** | **String** |  | [optional] 
**userStatus** | **Number** | User Status | [optional] 
